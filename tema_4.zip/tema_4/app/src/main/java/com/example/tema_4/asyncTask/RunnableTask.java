package com.example.tema_4.asyncTask;

import android.os.Handler;
import android.util.Log;

import java.util.concurrent.Callable;

public class RunnableTask<R> implements Runnable {

    private final Handler handler;
    private final Callable<R> asyncOperation;
    private final Callback<R> mainThreahOperation;

    public RunnableTask(Handler handler, Callable<R> asyncOperation, Callback<R> mainThreahOperation) {
        this.handler = handler;
        this.asyncOperation = asyncOperation;
        this.mainThreahOperation = mainThreahOperation;
    }

    @Override
    public void run() {
        try {
            final R result=asyncOperation.call();
            handler.post(new HandlerMessage<>(result,mainThreahOperation));
        } catch (Exception e) {
            Log.i("RunnableTask", "failed call runnableTask" + e.getMessage());
        }
    }
}
