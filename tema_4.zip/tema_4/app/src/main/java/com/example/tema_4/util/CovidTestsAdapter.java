package com.example.tema_4.util;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class CovidTestsAdapter extends ArrayAdapter<COVIDtests> {

    private Context context;
    private int resource;
    private List<COVIDtests> coviDtests;
    private LayoutInflater inflater;

    public CovidTestsAdapter(@NonNull Context context, int resource, @NonNull List<COVIDtests> objects,
                             LayoutInflater inflater) {
        super(context, resource, objects);
        this.context=context;
        this.resource=resource;
        this.coviDtests=objects;
        this.inflater=inflater;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View view=inflater.inflate(resource,parent, false);
        COVIDtests result=coviDtests.get(position);
        return view;
    }
}
