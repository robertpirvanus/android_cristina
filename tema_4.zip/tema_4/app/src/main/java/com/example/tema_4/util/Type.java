package com.example.tema_4.util;

public enum Type {
    PCR, fastTest;
}
