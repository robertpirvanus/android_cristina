package com.example.tema_4.asyncTask;

public interface Callback<R> {
    void runResultOnUiThread(R result);
}
