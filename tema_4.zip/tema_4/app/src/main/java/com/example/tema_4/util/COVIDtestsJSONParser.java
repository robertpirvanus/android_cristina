package com.example.tema_4.util;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class COVIDtestsJSONParser {
    public static final String SURNAME = "surname";
    public static final String NAME = "name";
    public static final String CNP = "CNP";


//    public static List<COVIDtests> fromJSON(String json) {
//        if(json==null || json.isEmpty()) {
//            return new ArrayList<>();
//        }
//        try {
//            JSONArray array=new JSONArray(json);
//            List <COVIDtests> results=new ArrayList<>();
//            for(int i=0;i<array.length();i++){
//                JSONObject object=array.getJSONObject(i);
//                String surname=object.getString(SURNAME);
//                String name=object.getString(NAME);
//                String cnp=object.getString(CNP);
//               //TestResult testResult=object.
//                //COVIDtests test=new COVIDtests(surname,name, CNP,new TestResult());
//                //results.add(test);
//            }
//            //return results;
//        } catch (JSONException e) {
//            e.printStackTrace();
//        }
//        return new ArrayList<>();
//    }
}
