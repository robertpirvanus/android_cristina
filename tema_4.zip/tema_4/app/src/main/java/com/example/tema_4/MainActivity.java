package com.example.tema_4;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.example.tema_4.asyncTask.AsyncTaskRunner;
import com.example.tema_4.asyncTask.Callback;
import com.example.tema_4.network.HttpManager;
import com.example.tema_4.util.COVIDtests;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;

public class MainActivity extends AppCompatActivity {
    private Button btnAdd;
    private static final String URL_COVID_tests="https://api.npoint.io/3985f54af90f07242c71";

    private List<COVIDtests> covidTests=new ArrayList<>();

    private AsyncTaskRunner asyncTaskRunner=new AsyncTaskRunner();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnAdd=findViewById(R.id.popescu_maria_cristina_btn_add);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(getApplicationContext(), AddActivity.class);
                startActivity(intent);
            }
        });
        getCovidTestsFromNetwork();
    }
    private void getCovidTestsFromNetwork() {
        Callable<String> asyncOperation=new HttpManager(URL_COVID_tests);

        Callback<String> mainThreadOperation= getMainThreadOperationForCOVIDtests();
        asyncTaskRunner.executeAsync(asyncOperation,mainThreadOperation);
    }

    @NonNull
    private Callback<String> getMainThreadOperationForCOVIDtests() {
        return new Callback<String>() {
            @Override
            public void runResultOnUiThread(String result) {
                Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
               // covidTests.addAll(COVIDtestsJSONParser.fromJSON(result));
                //notifyAdapter();
            }
        };
    }
}