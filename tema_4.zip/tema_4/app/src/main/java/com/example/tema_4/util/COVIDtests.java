package com.example.tema_4.util;

public class COVIDtests {
    private String surname;
    private String name;
    private String CNP;
    private TestResult testResult;

    public COVIDtests(String surname, String name, String CNP, TestResult testResult) {
        this.surname = surname;
        this.name = name;
        this.CNP = CNP;
        this.testResult = testResult;
    }

    public String getSurname() {
        return surname;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCNP() {
        return CNP;
    }

    public void setCNP(String CNP) {
        this.CNP = CNP;
    }

    public TestResult getTestResult() {
        return testResult;
    }

    public void setTestResult(TestResult testResult) {
        this.testResult = testResult;
    }

    @Override
    public String toString() {
        return "COVIDtests{" +
                "surname='" + surname + '\'' +
                ", name='" + name + '\'' +
                ", CNP='" + CNP + '\'' +
                ", testResult=" + testResult +
                '}';
    }
}