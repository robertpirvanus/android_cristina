package com.example.tema_4.util;

import java.util.Date;

public class TestResult {
    private String result;
    private Date date;
    private Type type;
    private Location location;

    public TestResult(String result, Date date, Type type, Location location) {
        this.result = result;
        this.date = date;
        this.type = type;
        this.location = location;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public Type getType() {
        return type;
    }

    public void setType(Type type) {
        this.type = type;
    }

    public Location getLocation() {
        return location;
    }

    public void setLocation(Location location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "TestResult{" +
                "result='" + result + '\'' +
                ", date=" + date +
                ", type=" + type +
                ", location=" + location +
                '}';
    }
}
